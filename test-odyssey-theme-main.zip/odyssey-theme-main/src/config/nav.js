export const nav = [
	{
		title: 'Home',
		slug: '/',
	},
	{
		title: 'Blog',
		slug: '/blog',
	},
	{
		title: 'About',
		slug: '/company/about',
	},
	{
		title: 'Contact',
		slug: '/company/contact',
	},
];
